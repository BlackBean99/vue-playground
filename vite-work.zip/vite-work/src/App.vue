<script setup>
import CompositionApi from './components/CompositionApi.vue'
import OpenApi from './components/OpenApi.vue';
import CalculatorBox from './components/CalculatorBox.vue';
import FlowerBox from './components/FlowerBox.vue';
</script>

<template>
  <div>
    <!-- <CompositionApi />
    <OpenApi />
    <CalculatorBox /> -->
    <FlowerBox />
  </div>

</template>

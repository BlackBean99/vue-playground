<template>
    <div>

        <Child v-slot:header>
            <h2>헤더 부분</h2>
        </Child>

        <Child>
            <h3>메인 부분</h3>
            <Hello />
        </Child>

        <Child v-slot:footer>
            <h2>푸터 부분입니다</h2>
        </Child>

    </div>
</template>

<script>
import Child from "./Child.vue";
import Hello from "./Hello.vue";

export default{
    name: "Parent",
    components:{
        Child, Hello,
    }
}

</script>
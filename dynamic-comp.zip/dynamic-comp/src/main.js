import { createApp } from 'vue'
import './style.css'
//import App from './App.vue'
import App from './App2.vue'

createApp(App).mount('#app')

<template>
    <div class="tab">

        <h1>미드웨이 해전</h1>

    </div>
</template>

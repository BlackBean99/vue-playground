<template>
    <div class="tab">

        <h1>산호해 해전</h1>

    </div>
</template>
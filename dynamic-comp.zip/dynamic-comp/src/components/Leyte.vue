<template>
    <div class="tab">

        <h1>레이테만 해전</h1>

    </div>
</template>
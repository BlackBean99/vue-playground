<template>
    <div class="tab">
        <h1>First Component</h1>
    </div>
</template>
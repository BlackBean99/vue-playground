<template>
    <div class="tab">
        <h1>Second Component</h1>
    </div>
</template>
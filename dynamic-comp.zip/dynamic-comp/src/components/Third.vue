<template>
    <div class="tab">
        <h1>Third Component</h1>
    </div>
</template>
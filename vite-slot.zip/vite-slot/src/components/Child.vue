
<template>
    <div>
        <h3>Child</h3>
        <slot>default content</slot>
    </div>
</template>


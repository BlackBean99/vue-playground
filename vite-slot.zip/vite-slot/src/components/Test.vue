<template>

    <div>
        <header>

        </header>

        <main>

        </main>

        <footer>
            
        </footer>
    </div>

</template>
<script setup>
import MyComp from './components/MyComp.vue'
</script>

<template>
  <div>

    <MyComp />

  </div>
</template>


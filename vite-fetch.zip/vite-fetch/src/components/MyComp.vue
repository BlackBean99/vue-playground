<template>
    <div>
        <table border="1">
        <tr>
            <th>번호</th><th>username</th><th>email</th><th>phone</th>
        </tr>

        <tr v-for="(member, index) in members" :key="index">
            <td>{{ index }}</td>
            <td>{{ member.username }}</td>
            <td>{{ member.email }}</td>
            <td>{{ member.phone }}</td>
        </tr>

        </table>
    </div>
</template>

<script>
export default{
    name:"MyComp",
    data(){
        return{
            members: []
        }
    },

    created(){
        // console.log('MyComp created ' + new Date());

        // 비동기 통신
        let url = "https://jsonplaceholder.typicode.com/users/";
        /*
            fetch( url, { method, headers } )
                .then((response)=>{})       // 성공여부 
                .then((json)=>{})           // 넘어온 데이터
                .catch((error)=>{})         // error
        */

        fetch(url, { method:"GET", headers:{'Content-Type':'application/json'} })
            .then((response)=>{
                if(response.ok){
                    console.log('response OK!');
                    return response.json();
                }
                throw new Error("Network response was not ok");
            })
            .then((json)=>{ // 넘어온 데이터를 받는다
                // console.log(json);
                // console.log(json[0].name);
                this.members = json;
            })
            .catch((error)=>{
                console.log('error:', error);
            });

    }

}    


</script>

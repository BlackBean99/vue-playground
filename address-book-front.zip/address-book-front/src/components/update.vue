<template>
    <div>   
        <h3>지인수정</h3>       
    </div>
</template>

<script>
export default{
    name:"update"
}
</script>